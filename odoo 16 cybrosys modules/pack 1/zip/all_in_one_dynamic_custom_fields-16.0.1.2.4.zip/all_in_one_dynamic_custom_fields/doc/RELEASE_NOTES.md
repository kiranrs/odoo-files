## Module <all_in_one_dynamic_custom_fields>

#### 03.08.2023
#### Version 16.0.1.1.3
##### ADD
- Initial commit for All in One Custom Dynamic Fields

#### 12.06.2024
#### Version 16.0.1.2.4
##### UPDATE
- The latest module update includes enhancements to the list view configuration. You can now add the newly created field to the selected list view at the desired position, with the option to enable or disable its visibility by default.