======================================
Odoo Professional Report Templates v16
======================================

Odoo Professional Report Templates.

Installation
============
Just select it from available modules to install it, there is no need to extra installations.

Features
========
* Sales Custom Template.
* Purchase Custom Template.
* Account Custom Template.
* Inventory Custom Template.

Credits
=======
Developer: gayathri@cybrosys.info


