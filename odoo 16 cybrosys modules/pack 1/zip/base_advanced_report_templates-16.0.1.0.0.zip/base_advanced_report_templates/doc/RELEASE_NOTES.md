## Module <base_advanced_report_templates>

#### 7.12.2022
#### Version 16.0.1.0.0
##### ADD
- Initial commit for Odoo Professional Report Templates Module
