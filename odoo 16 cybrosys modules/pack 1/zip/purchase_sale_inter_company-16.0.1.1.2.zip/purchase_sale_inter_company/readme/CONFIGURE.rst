To configure this module, you need to:
#. go to the menu *General Settings > Companies > Companies*.
#. Select one of the companies.
#. Go to the tab *Inter-Company* then the group *Purchase To Sale*.
#. If you check the option *Sale Auto Validation* in the configuration of company B, then when you validate a *Purchase Order* in company A with company B as supplier, the *Sale Order* will be automatically validated in company B with company A as customer.
