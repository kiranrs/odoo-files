## Module <hr_employee_creation_from_user>

#### 18.10.2021
#### Version 16.0.1.0.0
##### ADD
- Initial commit for Open HRMS Project