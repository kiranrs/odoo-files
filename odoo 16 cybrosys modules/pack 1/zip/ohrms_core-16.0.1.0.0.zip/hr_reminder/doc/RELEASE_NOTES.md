## Module hr_reminder

#### 04.11.2020
#### Version 16.0.1.0.0
##### ADD
- Initial commit for OpenHrms Project

#### 04.05.2023
#### Version 16.0.1.0.0
##### UPDATE
- Change the XML and JS file