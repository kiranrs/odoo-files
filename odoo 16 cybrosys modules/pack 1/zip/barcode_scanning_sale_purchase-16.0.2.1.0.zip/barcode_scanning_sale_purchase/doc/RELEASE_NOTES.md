## Module <barcode_scanning_sale_purchase>

#### 07.10.2021
#### Version 16.0.1.0.0
##### ADD
- Initial Commit

#### 16.10.2023
#### Version 16.0.2.1.0
##### ADD
- Inherited models and add fields, functions and add views for it
