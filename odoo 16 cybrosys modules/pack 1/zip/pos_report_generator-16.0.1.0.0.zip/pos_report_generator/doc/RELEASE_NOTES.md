## Module <pos_report_generator>

#### 03.06.2022
#### Version 16.0.1.0.0
#### ADD
Initial Commit for POS All in One Report Generator

#### 14.06.2023
#### Version 16.0.2.0.1
#### FIX
-Removed  the issue not displaying any information when a period is selected.
-Changed the date filter query.