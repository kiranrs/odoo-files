## Module <auto_database_backup>

#### 31.10.2022
#### Version 16.0.1.0.0
#### ADD

- Initial commit for auto_database_backup

## Module <auto_database_backup>

#### 26.09.2023
#### Version 16.0.2.0.1
#### ADD

- Next Cloud Integration and Amazon S3 are added and added active field customization if connection is successful only then active field will be able to edit.

## Module <auto_database_backup>

#### 07.12.2023
#### Version 16.0.3.0.2
#### UPDT

- Updated the database name check function which got access denied when list_db=False.

## Module <auto_database_backup>

#### 16.02.2024
#### Version 16.0.4.0.1
#### UPDT

- Fixed internal server error in Onedrive and Google Drive integration.

## Module <auto_database_backup>

#### 18.04.2024
#### Version 16.0.5.0.1
#### UPDT

- Fixed the error while inputting list_db = False in odoo conf file.

#### 29.06.2024
#### Version 16.0.6.0.1
#### UPDT

- Fixed the 0kb error on windows.
