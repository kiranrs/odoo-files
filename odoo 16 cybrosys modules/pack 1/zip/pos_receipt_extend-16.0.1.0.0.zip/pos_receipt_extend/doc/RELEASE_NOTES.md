## Module <pos_receipt_extend>

#### 01.10.2022
#### Version 16.0.1.0.0
#### ADD
- Initial commit for pos_receipt_extend

#### 23.05.2023
#### Version 16.0.2.0.1
##### FIX
-Removed the error of not displaying customer details in pos receipt.
-Changed the index file.

#### 11.09.2023
#### Version 16.0.2.0.1
##### FIX
-Removed the error of not displaying the receipt without choosing the partner.
