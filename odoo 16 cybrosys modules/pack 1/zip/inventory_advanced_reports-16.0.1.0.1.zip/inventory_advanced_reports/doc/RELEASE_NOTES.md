## Module <inventory_advanced_reports>

#### 28.01.2024
#### Version 16.0.1.0.0
##### ADD

- Initial Commit for Inventory Advanced Reports

#### 19.08.2024
#### Version 16.0.1.0.1
##### UPDT

- Fixed the issue in filtering of warehouses of same company
