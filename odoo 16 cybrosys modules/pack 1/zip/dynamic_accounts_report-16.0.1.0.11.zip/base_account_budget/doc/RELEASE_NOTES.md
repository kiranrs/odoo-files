## Module <kit_account_budget>

#### 06.10.2021
#### Version 16.0.1.0.0
#### ADD
- Initial commit for base_account_budget

### 18.07.2024
### Version 16.0.1.0.1
### UPDT

- Bug Fix-Fixed the issue when creating a new budget line.

