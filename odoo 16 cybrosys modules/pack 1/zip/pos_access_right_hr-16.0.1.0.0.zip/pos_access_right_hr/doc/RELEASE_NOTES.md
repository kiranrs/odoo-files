## Module <pos_access_right_hr>

#### 04.05.2023
#### Version 16.0.1.0.0
##### ADD
- Initial commit for POS Access Right

#### 02.01.2024
#### Version 16.0.1.0.1
##### FIX
- Fix the keyboard event handling issue
