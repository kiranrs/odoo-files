## Module <login_pos_direct>

#### 09.03.2023
#### Version 16.0.1.0.0
#### ADD
- Initial commit for Pos Direct Login
