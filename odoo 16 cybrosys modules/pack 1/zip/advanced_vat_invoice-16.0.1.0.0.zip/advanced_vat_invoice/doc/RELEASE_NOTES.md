## Module <advanced_vat_invoice>

#### 11.01.2024
#### Version 16.0.1.0.0
##### ADD

- Initial Commit for Advanced VAT Invoice
