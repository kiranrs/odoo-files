## Module <sale_customer_product_history>

#### 30.10.2022
#### Version 16.0.1.0.0
#### ADD
- Initial Commit for sale_customer_product_history
