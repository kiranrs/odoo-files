## Module <sale_discount_total>

#### 10.09.2021
#### Version 16.0.1.0.0
#### ADD
- Initial commit for Sale Discount On Total Amount


#### 12.08.2024
#### Version 16.0.1.1.1
#### UPDT
- bug fix in discount rounding