Sale Discount on Total Amount
=============================
Discount on Total in Sale and Invoice With Discount Limit and Approval

Configuration
=============
* No additional configurations needed

Company
-------
* `Cybrosys Techno Solutions <https://cybrosys.com/>`__

Credits
-------
* Developer: 	Faslu Rahman @cybrosys
*    		    V14: Muhammed P @cybrosys
*    		    V15: Sreerag E @cybrosys
                V16: Sahla Sherin

Contacts
--------
* Mail Contact : odoo@cybrosys.com
* Website : https://cybrosys.com

Bug Tracker
-----------
Bugs are tracked on GitHub Issues. In case of trouble, please check there if your issue has already been reported.

Maintainer
==========
.. image:: https://cybrosys.com/images/logo.png
   :target: https://cybrosys.com

This module is maintained by Cybrosys Technologies.

For support and more information, please visit `Our Website <https://cybrosys.com/>`__

Further information
===================
HTML Description: `<static/description/index.html>`__


