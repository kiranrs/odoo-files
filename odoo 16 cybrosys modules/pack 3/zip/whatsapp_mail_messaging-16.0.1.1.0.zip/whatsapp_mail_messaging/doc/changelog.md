## Module <whatsapp_mail_messaging>

#### 18.12.2021
#### Version 16.0.1.0.0
#### ADD
- Initial commit


#### 29.11.2023
#### Version 16.0.1.0.1
#### BUGFIX
- Added Default Message functionality where users can save message templates and use these templates for sending Whatsapp Message.

#### 20.05.2024
#### Version 16.0.1.1.0
#### UPDT
- Added new message template feature.