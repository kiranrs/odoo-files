## Module <advanced_dynamic_dashboard>

#### 22.03.2024
#### Version 16.0.1.0.0
#### ADD
- Initial commit for Advanced Dynamic Dashboard

#### 26.07.2024
#### Version 16.0.2.1.3
#### Updated
- Bug fix, updated the code in get_query() since there was an issue when we give group by as product_product model
