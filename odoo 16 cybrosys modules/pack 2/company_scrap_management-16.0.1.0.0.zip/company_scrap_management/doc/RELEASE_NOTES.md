## Module <company_scrap_management>

#### 06.01.2024
#### Version 16.0.1.0.0
#### ADD
- Initial commit for Scrap Management
