## Module <voice_note_in_chatter>

#### 10.03.2023
#### Version 16.0.1.0.0
#### ADD

- Voice Chat In Odoo
