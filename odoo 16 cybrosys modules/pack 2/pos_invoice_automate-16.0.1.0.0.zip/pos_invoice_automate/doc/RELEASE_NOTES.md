## Module <pos_invoice_automate>
#### 19.12.2023
#### Version 16.0.1.0.0
##### ADD
- Initial commit for POS Automate Invoice
