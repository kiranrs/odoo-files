## Module <expense_report_odoo>

#### 10.08.2023
#### Version 16.0.1.0.0
#### ADD

- Initial commit for Employee Expense Report
