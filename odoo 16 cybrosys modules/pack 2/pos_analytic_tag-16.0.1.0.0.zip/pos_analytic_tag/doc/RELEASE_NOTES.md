## Module <pos_analytic_tag>

#### 14.08.2023
#### Version 16.0.1.0.0
#### ADD

 - Initial Commit for PoS Analytic Tag