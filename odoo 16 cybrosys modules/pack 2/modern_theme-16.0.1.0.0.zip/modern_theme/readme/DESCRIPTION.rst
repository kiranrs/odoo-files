Modern theme is a Odoo backend theme for Community edition, with the latest template design methods and support full responsive.

Features:
    - Full modules suppot
    - Full responsive suppot
    - Full rtl support
    - Modern Style & modern color
    - Modification of form, list, kanban, calendar, pivot, graph, activity, mail, card, pos and dashboard views
    - Complete documentation and easy development
