Web responsive module is a requirement for installation.
First, install the web responsive module and then install the modern theme module.

