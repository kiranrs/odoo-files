Install the module and enjoy it. :)

